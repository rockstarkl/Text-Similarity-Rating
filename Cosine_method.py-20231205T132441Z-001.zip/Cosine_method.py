#csv_file_path = 'C:/Users/kuldeep.limbachiya/Downloads/DataNeuron_Task/Precily_Task/Precily_Text_Similarity.csv'  # Replace with the actual path to your CSV file

import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
import string
import re

# Download NLTK resources
import nltk
nltk.download('stopwords')
nltk.download('wordnet')

# Step 1: Read Data from CSV
csv_file_path = 'C:/Users/kuldeep.limbachiya/Downloads/DataNeuron_Task/Precily_Task/Precily_Text_Similarity.csv'
df = pd.read_csv(csv_file_path)

# Step 2: Text Preprocessing
stop_words = set(stopwords.words('english'))
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()
# Preprocessing part : Lowercase , Remove HTML tags,Numerical values, special characters, Punctuation , stopwords
# apply Lemmatization
def preprocess_text(text):
    # Lowercase
    text = text.lower()
    # Remove HTML tags
    text = re.sub(r'<.*?>', '', text)
    # Remove numerical digits
    text = re.sub(r'\d+', '', text)
    # Remove special characters
    text = re.sub(r'[^\w\s]', '', text)
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    # Remove stop words
    text = ' '.join([word for word in text.split() if word not in stop_words])
    # Lemmatization
    text = ' '.join([lemmatizer.lemmatize(word) for word in text.split()])

    return text

df['ProcessedColumn1'] = df['text1'].apply(preprocess_text)
df['ProcessedColumn2'] = df['text2'].apply(preprocess_text)

# Step 3: Tokenize and Calculate Cosine Similarity
vectorizer = CountVectorizer().fit(df['ProcessedColumn1'] + ' ' + df['ProcessedColumn2'])
vectorized_text1 = vectorizer.transform(df['ProcessedColumn1']).toarray()
vectorized_text2 = vectorizer.transform(df['ProcessedColumn2']).toarray()

cosine_sim = cosine_similarity(vectorized_text1, vectorized_text2)

# Step 4: Set a Threshold and Rate Similarity
threshold = 0.8  # Adjust this threshold based on your requirements
df['SimilarityRating'] = cosine_sim.mean(axis=1)

# Display the result
print(df[['ProcessedColumn1', 'ProcessedColumn2', 'SimilarityRating']])
